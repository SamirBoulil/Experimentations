# RESULTS OF EXPERIMENTATIONS :
## General information :
	 Number of cluster reference : 14 
	 Number of distance file treated : 2 
## Results for distance file name : data/distance-cosinus.csv 
	 - Result path is : "0_distance-cosinus_experimentations/" 
	 - Optimum cluster for fmesure at index : 69 for FMesure = 39.1806722689 
## Results for distance file name : data/distance-jaccard.csv 
	 - Result path is : "1_distance-jaccard_experimentations/" 
	 - Optimum cluster for fmesure at index : 57 for FMesure = 47.2025989883 
You can find all the best results in the resultats/ directory.